#include "Engine.h"
#include "Logging/Logger.h"

CEngine::~CEngine()
{
    
}

CEngine& CEngine::Get()
{
    static CEngine Instance;
    return Instance;
}

bool CEngine::Init(HWND hwnd, int width, int height, bool vsync, bool windowed)
{
    if (!m_Device.Init(hwnd, width, height, vsync, windowed))
    {
        return false;
    }

    if (!m_ShaderMgr.Init(m_Device.GetDevice()))
    {
        return false;
    }

    if (!m_TexMgr.Init(m_Device.GetDevice(), m_Device.GetContext()))
    {
        return false;
    }

   if (!m_Sprite.Init(&m_Device, &m_ShaderMgr))
    {
        return false;
    }

    // ���� �ؽ�ó (üĿ���� or �ܻ�)
    // üĿ: ���� ȸ��/����
    uint32_t c0 = 0xFFFFFFFF; // RGBA (0xAABBGGRR �ƴ�! ���⼱ 0xRRGGBBAA�� ä����)
    uint32_t c1 = 0xFFCCCCCC;
    if (!m_TexMgr.CreateCheckerTexture(128, 128, 16, c0, c1, m_DemoSRV))
    {
        // ���� �� �ܻ�
        m_TexMgr.CreateSolidTextureRGBA8(64, 64, 0xFFFFFFFF, m_DemoSRV);
    }

    return true;
}

void CEngine::Shutdown()
{
    m_Device.Shutdown();
}

void CEngine::BeginFrame()
{
    m_Renderer.BeginFrame(m_ClearColor);

    FInt2 sz = { (int)m_Device.GetViewport().Width, (int)m_Device.GetViewport().Height };
    FInt2 pos = { sz.X / 2 - 64, sz.Y / 2 - 64 };
    FInt2 size = { 128, 128 };
    float color[4] = { 1, 1, 1, 0.85f };          // ��¦ ����
    float uv[4] = { 0.f, 0.f, 1.f, 1.f };
    m_Sprite.Draw(sz, pos, size, m_DemoSRV.Get(), color, uv);
}

void CEngine::EndFrame()
{
    m_Renderer.EndFrame();
}

bool CEngine::Resize(int width, int height)
{
    return m_Device.Resize(width, height);
}