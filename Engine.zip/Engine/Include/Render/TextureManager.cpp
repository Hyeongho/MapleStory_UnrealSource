#include "TextureManager.h"
#include "../Logging/Logger.h"
#include "../SmartPointer/MakeShared.h"

CTextureManager::CTextureManager()
{
}

CTextureManager::~CTextureManager()
{
    
}

bool CTextureManager::Init(ID3D11Device* device, ID3D11DeviceContext* ctx)
{
    m_Device = device; 
    m_Ctx = ctx; 
    return true;
}

bool CTextureManager::CreateSolidTextureRGBA8(int w, int h, uint32_t rgba, ComPtr<ID3D11ShaderResourceView>& outSRV)
{
    std::vector<uint32_t> pixels(w * h, rgba);

    D3D11_TEXTURE2D_DESC td = {};
    td.Width = w; td.Height = h;
    td.MipLevels = 1; td.ArraySize = 1;
    td.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    td.SampleDesc.Count = 1;
    td.Usage = D3D11_USAGE_IMMUTABLE;
    td.BindFlags = D3D11_BIND_SHADER_RESOURCE;

    D3D11_SUBRESOURCE_DATA init = {};
    init.pSysMem = pixels.data();
    init.SysMemPitch = w * 4;

    ComPtr<ID3D11Texture2D> tex;
    HRESULT hr = m_Device->CreateTexture2D(&td, &init, tex.GetAddressOf());
    if (FAILED(hr)) 
    {
        return false;
    }

    D3D11_SHADER_RESOURCE_VIEW_DESC sd = {};
    sd.Format = td.Format;
    sd.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
    sd.Texture2D.MostDetailedMip = 0;
    sd.Texture2D.MipLevels = 1;

    return SUCCEEDED(m_Device->CreateShaderResourceView(tex.Get(), &sd, outSRV.GetAddressOf()));
}

bool CTextureManager::CreateCheckerTexture(int w, int h, int cell, uint32_t c0, uint32_t c1, ComPtr<ID3D11ShaderResourceView>& outSRV)
{
    std::vector<uint32_t> pixels(w * h);
    for (int y = 0; y < h; y++)
    {
        for (int x = 0; x < w; x++) {

            bool even = ((x / cell) + (y / cell)) % 2 == 0;
            pixels[y * w + x] = even ? c0 : c1;
        }
    }

    D3D11_TEXTURE2D_DESC td = {};
    td.Width = w; td.Height = h;
    td.MipLevels = 1; td.ArraySize = 1;
    td.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    td.SampleDesc.Count = 1;
    td.Usage = D3D11_USAGE_IMMUTABLE;
    td.BindFlags = D3D11_BIND_SHADER_RESOURCE;

    D3D11_SUBRESOURCE_DATA init = {};
    init.pSysMem = pixels.data();
    init.SysMemPitch = w * 4;

    ComPtr<ID3D11Texture2D> tex;
    HRESULT hr = m_Device->CreateTexture2D(&td, &init, tex.GetAddressOf());
    if (FAILED(hr)) 
    {
        return false;
    }

    D3D11_SHADER_RESOURCE_VIEW_DESC sd = {};
    sd.Format = td.Format;
    sd.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
    sd.Texture2D.MostDetailedMip = 0;
    sd.Texture2D.MipLevels = 1;

    return SUCCEEDED(m_Device->CreateShaderResourceView(tex.Get(), &sd, outSRV.GetAddressOf()));
}