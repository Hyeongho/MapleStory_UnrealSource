#pragma once

#include <d3d11.h>

extern D3D11_INPUT_ELEMENT_DESC SpriteVertexLayout[];
extern D3D11_INPUT_ELEMENT_DESC layout[];
extern const UINT SpriteVertexLayoutCount;