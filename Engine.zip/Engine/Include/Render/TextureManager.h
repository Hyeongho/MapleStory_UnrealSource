#pragma once

#include "../EngineInfo.h"

class CTextureManager
{
public:
    CTextureManager();
    ~CTextureManager();

public:
    bool Init(ID3D11Device* device, ID3D11DeviceContext* ctx);
    void Shutdown() {}

    bool CreateSolidTextureRGBA8(int w, int h, uint32_t rgba, ComPtr<ID3D11ShaderResourceView>& outSRV);

    bool CreateCheckerTexture(int w, int h, int cell, uint32_t c0, uint32_t c1, ComPtr<ID3D11ShaderResourceView>& outSRV);

private:
    ID3D11Device* m_Device = nullptr;
    ID3D11DeviceContext* m_Ctx = nullptr;
};

