#pragma once

#include "EngineInfo.h"
#include "Device.h"
#include "Render/RenderTargetManager.h"
#include "Render/SpriteRenderer.h"
#include "Render/Shader/ShaderManager.h"
#include "Render/Renderer.h"

class CEngine
{
public:
    static CEngine& Get();

    bool Init(HWND hwnd, int width, int height, bool vsync = true, bool windowed = true);
    void Shutdown();

    void BeginFrame();
    void EndFrame();

    bool Resize(int width, int height);

    CDevice& GetDevice() 
    { 
        return m_Device; 
    }

    CRenderer& GetRenderer() 
    { 
        return m_Renderer; 
    }

private:
    CEngine() = default;
    ~CEngine();

private:
    CDevice m_Device;
    CRenderTargetManager m_RTM{ &m_Device };
    CRenderer m_Renderer{ &m_Device, &m_RTM };

    float m_ClearColor[4] = { 0.08f, 0.08f, 0.12f, 1.0f };

private:
    // ���� ��� �Ʒ��� �߰�
    CShaderManager   m_ShaderMgr;
    CTextureManager  m_TexMgr;
    CSpriteRenderer  m_Sprite;

    // ����� �ؽ�ó
    ComPtr<ID3D11ShaderResourceView> m_DemoSRV;
};

